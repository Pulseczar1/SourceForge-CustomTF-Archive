/*
 *  QWProgs-TF2003
 *  Copyright (C) 2004  [sd] angel
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 *  $Id: spy.h,v 1.4 2004/12/23 03:16:14 AngelD Exp $
 */
void    HallucinationTimer(  );
void    TranquiliserTimer(  );

void    SetGasSkins( gedict_t * pl );
void 	ResetGasSkins( gedict_t * pl );
void 	Spy_RemoveDisguise( gedict_t * spy );
void 	TeamFortress_SpyChangeSkin( int class );
void 	TeamFortress_SpyChangeColor( int teamno );
void    TeamFortress_SpyFeignDeath( int issilent );

void spy_diea1();
void spy_diea2();
void spy_diea3();
void spy_diea4();
void spy_diea5();
void spy_diea6();
void spy_diea7();
void spy_diea8();
void spy_diea9();
void spy_diea10();
void spy_diea11();
void spy_dieb1();
void spy_dieb2();
void spy_dieb3();
void spy_dieb4();
void spy_dieb5();
void spy_dieb6();
void spy_dieb7();
void spy_dieb8();
void spy_dieb9();
void spy_diec1();
void spy_diec2();
void spy_diec3();
void spy_diec4();
void spy_diec5();
void spy_diec6();
void spy_diec7();
void spy_diec8();
void spy_diec9();
void spy_diec10();
void spy_diec11();
void spy_diec12();
void spy_diec13();
void spy_diec14();
void spy_diec15();
void spy_died1();
void spy_died2();
void spy_died3();
void spy_died4();
void spy_died5();
void spy_died6();
void spy_died7();
void spy_died8();
void spy_died9();
void spy_diee1();
void spy_diee2();
void spy_diee3();
void spy_diee4();
void spy_diee5();
void spy_diee6();
void spy_diee7();
void spy_diee8();
void spy_diee9();
void spy_die_ax1();
void spy_die_ax2();
void spy_die_ax3();
void spy_die_ax4();
void spy_die_ax5();
void spy_die_ax6();
void spy_die_ax7();
void spy_die_ax8();
void spy_die_ax9();
void spy_upb1();
void spy_upb2();
void spy_upb3();
void spy_upb4();
void spy_upb5();
void spy_upb6();
void spy_upb7();
void spy_upb8();
void spy_upb9();
void spy_upc1();
void spy_upc2();
void spy_upc3();
void spy_upc4();
void spy_upc5();
void spy_upc6();
void spy_upc7();
void spy_upc8();
void spy_upc9();
void spy_upc10();
void spy_upc11();
void spy_upc12();
void spy_upc13();
void spy_upc14();
void spy_upc15();
void spy_upd1();
void spy_upd2();
void spy_upd3();
void spy_upd4();
void spy_upd5();
void spy_upd6();
void spy_upd7();
void spy_upd8();
void spy_upd9();
void spy_upe1();
void spy_upe2();
void spy_upe3();
void spy_upe4();
void spy_upe5();
void spy_upe6();
void spy_upe7();
void spy_upe8();
void spy_upe9();
void spy_upaxe1();
void spy_upaxe2();
void spy_upaxe3();
void spy_upaxe4();
void spy_upaxe5();
void spy_upaxe6();
void spy_upaxe7();
void spy_upaxe8();
void spy_upaxe9();
