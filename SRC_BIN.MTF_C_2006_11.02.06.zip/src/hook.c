/*
 *  QWProgs-TF2003
 *  Copyright (C) 2004  [sd] angel
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 *  $Id: hook.c,v 1.4 2005/05/16 06:31:38 AngelD Exp $
 */
/*
===========================================================================
Quakeworld-friendly grapple hook code by Wedge (Steve Bond)
           visit Quake Command http://www.nuc.net/quake 


Original 'Morning Star' (Grapple Hook) by "Mike" <amichael@asu.alasu.edu> 
I took care to preserve the speed and damage values of the original
Morning Star. Depending on latency, performance should be near exact.
===========================================================================
*/

#include "g_local.h"
//
// Reset_Grapple - Removes the hook and resets its owner's state.
//                 expects a pointer to the hook
//
void Reset_Grapple( gedict_t * rhook )
{
	gedict_t *owner = PROG_TO_EDICT( rhook->s.v.owner );

	sound( owner, 1, "doors/ddoor2.wav", 1, 0 );
	owner->on_hook = 0;
	owner->hook_out = 0;
	owner->fire_held_down = 0;
	owner->s.v.weaponframe = 0;
	rhook->s.v.think = ( func_t ) SUB_Remove;
	rhook->s.v.nextthink = g_globalvars.time;
}

void Reset_My_Grapple ( )
{
	gedict_t *owner = PROG_TO_EDICT( self->s.v.owner );

	sound( owner, 1, "doors/ddoor2.wav", 1, 1 );
	owner->on_hook = 0;
	owner->hook_out = 0;
	owner->fire_held_down = 0;
	owner->s.v.weaponframe = 0;
//	self.owner.off_hook = time + 1;
	self->s.v.think = ( func_t ) SUB_Remove;
	self->s.v.nextthink = g_globalvars.time;
}

//
// Grapple_Track - Constantly updates the hook's position relative to
//                 what it's hooked to. Inflicts damage if attached to
//                 a player that is not on the same team as the hook's
//                 owner.
//
void Grapple_Track(  )
{
//	vec3_t  spray;
	gedict_t *owner = PROG_TO_EDICT( self->s.v.owner );
	gedict_t *enemy = PROG_TO_EDICT( self->s.v.enemy );

	// drop the hook if owner is dead or has released the button
	if ( !owner->on_hook || owner->s.v.health <= 0 )
	{
		Reset_Grapple( self );
		return;
	}
        // If the hook is not attached to the player, constantly copy
        // copy the target's velocity. Velocity copying DOES NOT work properly
        // for a hooked client. 
	if ( strneq( enemy->s.v.classname, "player" ) )
		VectorCopy( enemy->s.v.velocity, self->s.v.velocity );
	self->s.v.nextthink = g_globalvars.time + 0.1;
}

//
// MakeLink - spawns the chain link entities
//
gedict_t *MakeLink( )
{
	newmis = spawn(  );

	g_globalvars.newmis = EDICT_TO_PROG( newmis );
	newmis->s.v.movetype = MOVETYPE_FLYMISSILE;
	newmis->s.v.solid = SOLID_NOT;
	newmis->s.v.owner = EDICT_TO_PROG( self ); // SELF is the hook!

	//SetVector( newmis->s.v.avelocity, 200, 200, 200 );

	setmodel( newmis, "progs/rope.mdl" );
	vectoangles( self->s.v.velocity, newmis->s.v.angles );

	setorigin( newmis, PASSVEC3( self->s.v.origin ) );
	setsize( newmis, 0, 0, 0, 0, 0, 0 );

	return newmis;
}

//
// Remove_Chain - Removes all chain link entities; this is a separate
//                function because CLIENT also needs to be able
//                to remove the chain. Only one function required to
//                remove all links.
//
void Remove_Chain(  )
{
	gedict_t *goalentity;

	self->s.v.think = ( func_t ) SUB_Remove;
	self->s.v.nextthink = g_globalvars.time;
	if ( self->s.v.goalentity )
	{
		goalentity = PROG_TO_EDICT( self->s.v.goalentity );
		goalentity->s.v.think = ( func_t ) SUB_Remove;
		goalentity->s.v.nextthink = g_globalvars.time;
		if ( goalentity->s.v.goalentity )
		{
			goalentity = PROG_TO_EDICT( goalentity->s.v.goalentity );
			goalentity->s.v.think = ( func_t ) SUB_Remove;
			goalentity->s.v.nextthink = g_globalvars.time;
		}
	}
}

//
// Update_Chain - Repositions the chain links each frame. This single function
//                maintains the positions of all of the links. Only one link
//                is thinking every frame. 
//
void Update_Chain(  )
{
	vec3_t	t1,t2,t3;
	vec3_t  temp/*, v*/;
	gedict_t *owner = PROG_TO_EDICT( self->s.v.owner );

	if ( !owner->hook_out )
	{
		self->s.v.think = ( func_t ) Remove_Chain;
		self->s.v.nextthink = g_globalvars.time;
		return;
	}
	VectorSubtract( owner->hook->s.v.origin, owner->s.v.origin, temp );

        // These numbers are correct assuming 3 links.
        // 4 links would be *20 *40 *60 and *80
	t1[0] = temp[0] * 0.3 + owner->s.v.origin[0];t1[1] = temp[1] * 0.3 + owner->s.v.origin[1];t1[2] = temp[2] * 0.3 + owner->s.v.origin[2];
	t2[0] = temp[0] * 0.6 + owner->s.v.origin[0];t2[1] = temp[1] * 0.6 + owner->s.v.origin[1];t2[2] = temp[2] * 0.6 + owner->s.v.origin[2];
	t3[0] = temp[0] * 0.9 + owner->s.v.origin[0];t3[1] = temp[1] * 0.9 + owner->s.v.origin[1];t3[2] = temp[2] * 0.9 + owner->s.v.origin[2];
	setorigin( self, PASSVEC3( t1 ) );
	setorigin( PROG_TO_EDICT( self->s.v.goalentity ), PASSVEC3( t2 ) );
	setorigin( PROG_TO_EDICT( PROG_TO_EDICT(self->s.v.goalentity)->s.v.goalentity ), PASSVEC3( t3 ) );
	vectoangles( temp, self->s.v.angles );
	vectoangles( temp, PROG_TO_EDICT( self->s.v.goalentity )->s.v.angles );
	vectoangles( temp, PROG_TO_EDICT( PROG_TO_EDICT(self->s.v.goalentity)->s.v.goalentity )->s.v.angles );

	//self.nextthink = time + 0.2;
	self->s.v.nextthink = g_globalvars.time + 0.2;
/*	VectorScale( temp, 0.25, v );
	VectorAdd( v, owner->s.v.origin, v );
	setorigin( self, PASSVEC3( v ) );

	VectorScale( temp, 0.5, v );
	VectorAdd( v, owner->s.v.origin, v );
	setorigin( self, PASSVEC3( v ) );

	VectorScale( temp, 0.75, v );
	VectorAdd( v, owner->s.v.origin, v );
	setorigin( self, PASSVEC3( v ) );

	vectoangles( temp, newmis->s.v.angles );

	self->s.v.nextthink = g_globalvars.time + 0.1;*/
}

//
// Build_Chain - Builds the chain (linked list)
//
void Build_Chain(  )
{
	gedict_t *goalentity;

	goalentity = MakeLink(  );
	self->s.v.goalentity = EDICT_TO_PROG( goalentity );
	goalentity->s.v.think = ( func_t ) Update_Chain;
	goalentity->s.v.nextthink = g_globalvars.time + 0.1;
	goalentity->s.v.owner = self->s.v.owner;

	goalentity->s.v.goalentity = EDICT_TO_PROG( MakeLink(  ) );
	PROG_TO_EDICT( goalentity->s.v.goalentity )->s.v.goalentity = EDICT_TO_PROG( MakeLink(  ) );
}

//
// Check_Overhead - Makes sure there is sufficient headroom above the player
//                  so that setorigin doesn't stick them into a wall. I tried
//                  to compare pointcontents, but that was too flaky.
//
int Check_Overhead(  )
{
	vec3_t  src;
	vec3_t  end;
	vec3_t  tmp;
	gedict_t *owner = PROG_TO_EDICT( self->s.v.owner );

	makevectors( owner->s.v.angles );

        // The following comparisons could be optimized by doing away with
        // SRC and END, and plugging the values directly into the traceline
        // function calls. Using SRC and END made debugging easier. You
        // decide if it's worth it.

        // quick check right above head
	VectorCopy( owner->s.v.origin, src );
	VectorCopy( owner->s.v.origin, end );
	src[2] -= 24;
	end[2] -= 24;

	traceline( PASSVEC3( src ), PASSVEC3( end ), 0, owner );
	if ( g_globalvars.trace_fraction != 1 )
		return 0;

	VectorCopy( owner->s.v.origin, src );
	VectorCopy( owner->s.v.origin, end );
	src[2] -= 24;
	end[2] -= 24;
	VectorScale( g_globalvars.v_forward, 16, tmp );
	VectorSubtract( src, tmp, src );
	VectorCopy( src, end );
	end[2] += 58;
	traceline( PASSVEC3( src ), PASSVEC3( end ), 0, owner );
	if ( g_globalvars.trace_fraction != 1 )
		return 0;

	VectorCopy( owner->s.v.origin, src );
	VectorCopy( owner->s.v.origin, end );
	src[2] -= 24;
	end[2] -= 24;
	VectorScale( g_globalvars.v_forward, 16, tmp );
	VectorAdd( src, tmp, src );
	VectorCopy( src, end );
	end[2] += 58;
	traceline( PASSVEC3( src ), PASSVEC3( end ), 0, owner );
	if ( g_globalvars.trace_fraction != 1 )
		return 0;

	VectorCopy( owner->s.v.origin, src );
	VectorCopy( owner->s.v.origin, end );
	src[2] -= 24;
	end[2] -= 24;
	VectorScale( g_globalvars.v_right, 16, tmp );
	VectorSubtract( src, tmp, src );
	VectorCopy( src, end );
	end[2] += 58;
	traceline( PASSVEC3( src ), PASSVEC3( end ), 0, owner );
	if ( g_globalvars.trace_fraction != 1 )
		return 0;

	VectorCopy( owner->s.v.origin, src );
	VectorCopy( owner->s.v.origin, end );
	src[2] -= 24;
	end[2] -= 24;
	VectorScale( g_globalvars.v_right, 16, tmp );
	VectorAdd( src, tmp, src );
	VectorCopy( src, end );
	end[2] += 58;
	traceline( PASSVEC3( src ), PASSVEC3( end ), 0, owner );
	if ( g_globalvars.trace_fraction != 1 )
		return 0;

	return 1;
}

//
// Anchor_Grapple - Tries to anchor the grapple to whatever it touches
//
void Anchor_Grapple(  )
{
	gedict_t *owner = PROG_TO_EDICT( self->s.v.owner );
	int     test;

	if ( other == owner )
		return;

        // DO NOT allow the grapple to hook to any projectiles, no matter WHAT!
        // if you create new types of projectiles, make sure you use one of the
        // classnames below or write code to exclude your new classname so
        // grapples will not stick to them.
	if ( streq( other->s.v.classname, "missile" ) || streq( other->s.v.classname, "grenade" )
	     || streq( other->s.v.classname, "spike" ) || streq( other->s.v.classname, "hook" ) )
		return;

        // Don't stick the the sky.
	if ( trap_pointcontents( PASSVEC3( self->s.v.origin ) ) == CONTENT_SKY )
	{
		Reset_Grapple( self );
		return;
	}
	// Cannot hurt players with the grapple
//	if ( streq( other->s.v.classname, "player" ) )
//	{
//		Reset_Grapple( self );
//		return;
//	} else
	{
		
                // One point of damage inflicted upon impact. Subsequent
                // damage will only be done to PLAYERS... this way secret
                // doors and triggers will only be damaged once.
		if ( other->s.v.takedamage ) {
			T_Damage( other, self, owner, 1 );
			sound( self, 1, "shambler/smack.wav", 1, 1 );
		}
		else
			sound( self, 1, "player/axhit2.wav", 1, 1 );

		SetVector( self->s.v.velocity, 0, 0, 0 );
		SetVector( self->s.v.avelocity, 0, 0, 0 );
	}
        // conveniently clears the sound channel of the CHAIN1 sound,
        // which is a looping sample and would continue to play. Tink1 is
        // the least offensive choice, as NULL.WAV loops and clogs the
        // channel with silence
	sound( self, 1, "weapons/bounce.wav", 1, 1 );
	sound( owner, 0, "weapons/retract.wav", 0.8, 1 );
	owner->s.v.ammo_cells = 0;
	if ( !owner->s.v.button0 )
	{
		Reset_Grapple( self );
		return;
	}
        // our last chance to avoid being picked up off of the ground.
        // check over the client's head to make sure there is one unit
        // clearance so we can lift him off of the ground.
	test = Check_Overhead(  );
	if ( !test )
	{
		Reset_Grapple( self );
		return;
	}
	owner->on_hook = 1;
	if ( ( int ) owner->s.v.flags & 512 )
	{
		owner->s.v.flags = ( int ) owner->s.v.flags - 512;
		setorigin( owner, PASSVEC3( owner->s.v.origin ) + 1 );
	}
        // CHAIN2 is a looping sample. Use LEFTY as a flag so that client.qc
        // will know to only play the tink sound ONCE to clear the weapons
        // sound channel. (Lefty is a leftover from AI.QC, so I reused it to
        // avoid adding a field)
	owner->lefty = 1;
	self->s.v.classname = "bot";
	self->team_no = 0;
	self->s.v.takedamage = 1;
	self->s.v.health = 1;
	self->th_die = Reset_My_Grapple;
	self->s.v.enemy = EDICT_TO_PROG( other );// remember this guy!
	self->s.v.think = ( func_t ) Grapple_Track;
	self->s.v.nextthink = g_globalvars.time;
	//self->s.v.solid = SOLID_NOT;
	self->s.v.touch = ( func_t ) SUB_Null;
}

//
// Throw_Grapple - called from WEAPONS.QC, 'fires' the grapple
//
void Throw_Grapple(  )
{
	vec3_t  v;

	if ( self->hook_out )// reject subsequent calls from player.qc
		return;

	KickPlayer( -1, self );

	newmis = spawn(  );
	g_globalvars.newmis = EDICT_TO_PROG( newmis );
	newmis->s.v.movetype = MOVETYPE_FLYMISSILE;
	newmis->s.v.solid = SOLID_BBOX;
	newmis->s.v.owner = EDICT_TO_PROG( self );// newmis belongs to me
	self->hook = newmis;// This is my newmis
	newmis->s.v.classname = "hook";

	makevectors( self->s.v.v_angle );
	if (self->playerclass == PC_SPY)
		VectorScale( g_globalvars.v_forward, 2000, newmis->s.v.velocity );
	else
		VectorScale( g_globalvars.v_forward, 800, newmis->s.v.velocity );
	// set the facing of the grapple
	vectoangles( newmis->s.v.velocity, newmis->s.v.angles );

	newmis->s.v.touch = ( func_t ) Anchor_Grapple;
	newmis->s.v.think = ( func_t ) Build_Chain;
	newmis->s.v.nextthink = g_globalvars.time + 0.1; // don't jam newmis and links into same packet

	setmodel( newmis, "progs/hook.mdl" );
	VectorScale( g_globalvars.v_forward, 16, v );
	VectorAdd( self->s.v.origin, v, v );
	v[2] += 16;
	setorigin( newmis, PASSVEC3( v ) );
//	setsize( newmis, 0, 0, 0, 0, 0, 0 );
	setsize( newmis, -1, -1, -1, 1, 1, 1 );

	self->hook_out = 1;
	self->fire_held_down = 1;
}

//
// Service_Grapple - called each frame by CLIENT.QC if client is ON_HOOK
//
void Service_Grapple(  )
{
	vec3_t  hook_dir;
	gedict_t *enemy;
	gedict_t *goalentity;

	// drop the hook if player lets go of button
	if ( !self->s.v.button0 )
	{
		self->fire_held_down = 0;
		if ( self->current_weapon == WEAP_HOOK )
			Reset_Grapple( self->hook );
	}
	enemy = PROG_TO_EDICT( self->hook->s.v.enemy );
	// If hooked to a player, track them directly!
	if ( streq( enemy->s.v.classname, "player" ) )
	{
		VectorSubtract( enemy->s.v.origin, self->s.v.origin, hook_dir );
	}
	// else, track to hook
	else
	{
		if ( strneq( enemy->s.v.classname, "player" ) )
			VectorSubtract( self->hook->s.v.origin, self->s.v.origin, hook_dir );
	}
	normalize( hook_dir, self->s.v.velocity );
	VectorScale( self->s.v.velocity, self->maxfbspeed * 2, self->s.v.velocity );
	if ( vlen( hook_dir ) <= 100 && self->lefty )
	{
                // If there is a chain, ditch it now. We're
                // close enough. Having extra entities lying around
                // is never a good idea.
		if ( self->hook->s.v.goalentity )
		{
			goalentity = PROG_TO_EDICT( self->hook->s.v.goalentity );
			goalentity->s.v.think = ( func_t ) Remove_Chain;
			goalentity->s.v.nextthink = g_globalvars.time;
		}
		self->lefty = 0;// we've reset the sound channel.
	}
	if ( self->grappleupdatetime < g_globalvars.time ) {
		self->s.v.currentammo = self->s.v.ammo_cells;
		self->grappleupdatetime = g_globalvars.time + 1;
	}
	else
		self->grappleupdatetime = g_globalvars.time + 1;
}
